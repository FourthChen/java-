package com.xhtx.service;

import com.xhtx.pojo.Author;


public interface AuthorService {
    Author getAuthorByID(int authorID);
}
