/*
SQLyog Enterprise v12.09 (64 bit)
MySQL - 5.7.33-log : Database - ssmbuild
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`ssmbuild` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ssmbuild`;

/*Table structure for table `author` */

DROP TABLE IF EXISTS `author`;

CREATE TABLE `author` (
  `authorID` int(10) NOT NULL AUTO_INCREMENT COMMENT '作者ID',
  `authorName` varchar(100) NOT NULL COMMENT '作者名',
  PRIMARY KEY (`authorID`),
  KEY `authorID` (`authorID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `author` */

insert  into `author`(`authorID`,`authorName`) values (1,'小胡'),(2,'大胡');

/*Table structure for table `books` */

DROP TABLE IF EXISTS `books`;

CREATE TABLE `books` (
  `bookID` mediumint(8) NOT NULL AUTO_INCREMENT,
  `bookName` varchar(100) NOT NULL COMMENT '书名',
  `bookCounts` int(11) NOT NULL COMMENT '数量',
  `aid` int(10) NOT NULL COMMENT '作者外键',
  PRIMARY KEY (`bookID`),
  KEY `kaid` (`aid`),
  CONSTRAINT `kaid` FOREIGN KEY (`aid`) REFERENCES `author` (`authorID`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

/*Data for the table `books` */

insert  into `books`(`bookID`,`bookName`,`bookCounts`,`aid`) values (1,'学习mybatis',10,2),(2,'学习springmvc',5,2),(3,'学习mybatis',5,1),(4,'学习spring',5,1),(5,'学习springmvc',5,2),(6,'学习mybatis',5,1),(7,'学习spring',5,1),(8,'学习springmvc',5,2),(9,'学习mybatis',5,1),(10,'学习spring',5,1),(11,'学习springmvc',5,2),(12,'学习mybatis',5,1),(13,'学习spring',5,1),(14,'学习springmvc',5,2),(15,'学习mybatis',5,1),(16,'学习spring',5,1),(17,'学习springmvc',5,2),(18,'学习mybatis',5,1),(19,'学习spring',5,1),(20,'学习springmvc',5,2),(21,'学习mybatis',5,1),(22,'学习spring',5,1),(23,'学习springmvc',5,2),(24,'学习mybatis',5,1),(25,'学习spring',5,1),(26,'学习springmvc',5,2),(27,'学习mybatis',5,1),(28,'学习spring',5,1),(29,'学习springmvc',5,2),(30,'学习mybatis',5,1),(31,'学习spring',5,1),(32,'学习springmvc',5,2),(33,'学习mybatis',5,1),(34,'学习spring',5,1),(35,'学习springmvc',5,2),(36,'学习mybatis',5,1),(37,'学习spring',5,1),(38,'学习springmvc',5,2),(39,'学习mybatis',5,1),(40,'学习spring',5,1),(41,'学习springmvc',5,2),(42,'学习mybatis',5,1),(43,'学习spring',5,1),(44,'hahahha ',11,1);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `password` int(10) NOT NULL COMMENT '密码',
  `email` varchar(100) NOT NULL COMMENT '邮箱',
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`username`,`password`,`email`,`id`) values ('胡萝卜',123,'2640370271@qq.com',3),('张三',456,'2640370271@qq.com',5);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
